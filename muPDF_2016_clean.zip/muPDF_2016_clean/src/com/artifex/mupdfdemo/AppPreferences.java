
package com.artifex.mupdfdemo;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class AppPreferences {
     private static final String APP_SHARED_PREFS = "com.tssw.mupdf.preferences"; //  Name of the file -.xml
     private SharedPreferences appSharedPrefs;
     private Editor prefsEditor;

     public AppPreferences(Context context)
     {
         this.appSharedPrefs = context.getSharedPreferences(APP_SHARED_PREFS, Activity.MODE_PRIVATE);
         this.prefsEditor = appSharedPrefs.edit();
     }

     public String getSCAC() {
         return appSharedPrefs.getString("scac", "");
     }

     public void setSCAC(String text) {
         prefsEditor.putString("scac", text);
         prefsEditor.commit();
     }
     public String getUserID() {
         return appSharedPrefs.getString("userID", "");
     }

     public void setUserID(String text) {
         prefsEditor.putString("userID", text);
         prefsEditor.commit();
     }     
     
     public String getSessionID() {
         return appSharedPrefs.getString("sessionID", "");
     }

     public void setSessionID(String text) {
         prefsEditor.putString("sessionID", text);
         prefsEditor.commit();
     }  
     
     //status : idle, starting, recording, stopping
     public String getRecordingStatus() {
         return appSharedPrefs.getString("recordingStatus", "");
     }

     public void setRecordingStatus(String text) {
         prefsEditor.putString("recordingStatus", text);
         prefsEditor.commit();
     }

    @Override
    public String toString() {
        String result="";
        
        result+= "recordingStatus: "+getRecordingStatus();
        result+= "\nsessionID: "+getSessionID();
        result+= "\nscac: "+getSCAC();
        result+= "\nuserID: "+getUserID();
        result+= "\nlocationIntentServiceBusy: "+getLocationIntentServiceBusy();
        return result;
    }
     public void setLocationIntentServiceBusy(boolean busy) {
         prefsEditor.putBoolean("locationIntentServiceBusy", busy);
         prefsEditor.commit();
     }    
     public boolean getLocationIntentServiceBusy() {
         return appSharedPrefs.getBoolean("locationIntentServiceBusy",false);
     }        

     
     
     public void setSuperuserMode(boolean su) {
         prefsEditor.putBoolean("superuserMode", su);
         prefsEditor.commit();
     }    
     public boolean getSuperuserMode() {
         return appSharedPrefs.getBoolean("superuserMode",false);
     }      
     
     
     
     
     public void setSpinnerFrequency(int i) {
         prefsEditor.putInt("spinnerFrequency", i);
         prefsEditor.commit();
     }    
     public int getSpinnerFrequency() {
         return appSharedPrefs.getInt("spinnerFrequency",6);
     } 

     public void removePackageFromList(String listName, String removedPackage){
         String json=appSharedPrefs.getString(listName, "");
         Type listType = new TypeToken<ArrayList<String>>() {}.getType();
         ArrayList<String> array=null;
            if (!json.equals("")){
                array = new Gson().fromJson(json, listType);
            }
            else array = new ArrayList<String>();
         array.remove(removedPackage);
         json = new Gson().toJson(array);
         prefsEditor.putString(listName, json);
         prefsEditor.commit();
     }
          
     public void addPackageToList(String listName, String newPackage){
         String json=appSharedPrefs.getString(listName, "");
         Type listType = new TypeToken<ArrayList<String>>() {}.getType();
         ArrayList<String> array=null;
            if (!json.equals("")){
                array = new Gson().fromJson(json, listType);
            }
            else array = new ArrayList<String>();
        if(!array.contains(newPackage))            
            array.add(newPackage);
         json = new Gson().toJson(array);
         prefsEditor.putString(listName, json);
         prefsEditor.commit();
     }
     
     public ArrayList<String> getPackageList(String listName){
         String json=appSharedPrefs.getString(listName, "");
         if (json.equals(""))
                 return new ArrayList<String>();
         Type listType = new TypeToken<ArrayList<String>>() {}.getType();
         ArrayList<String> array= new Gson().fromJson(json, listType);
         return array;
     }
     
     
     public int getSpinnerFrequencyTimer() {
         int i = getSpinnerFrequency();
         switch(i){
             
             case 0 :  {
                 return 30*1000;
             }
             case 1 :  {
                 return 60*1000;
             }
             case 2 :  {
                 return 60*2*1000;
             }
             case 3 :  {
                 return 60*3*1000;
             }                 
             case 4 :  {
                 return 60*5*1000;
             }
             case 5 :  {
                 return 60*10*1000;
             }                 
             case 6 :  {
                 return 60*15*1000;
             }                      
         }
         return 15*60*1000;
     }         
     
     
     public void setSpinnerGPSTTL(int i) {
         prefsEditor.putInt("spinnerGPSTTL", i);
         prefsEditor.commit();
     }    
     public int getSpinnerGPSTTL() {
         return appSharedPrefs.getInt("spinnerGPSTTL",3);
     }              

     public int getSpinnerGPSTTLTimer() {
         int i = getSpinnerGPSTTL();
         switch(i){
             
             case 0 :  {
                 return 30*1000;
             }
             case 1 :  {
                 return 60*1000;
             }
             case 2 :  {
                 return 60*2*1000;
             }
             case 3 :  {
                 return 60*3*1000;
             }                 
             case 4 :  {
                 return 60*5*1000;
             }                      
         }
         return 5*60*1000; //5minutes
     }       
     
}