/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.artifex.mupdfdemo.extra;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;
import com.artifex.mupdfdemo.AppPreferences;
import com.tssw.newmupdf.R;

/**
 *
 * @author Andrei
 */



public class SettingsActivity extends TabActivity implements View.OnClickListener {
    protected AppPreferences appPrefs;   
    
    private static final String TAG = "com.tssw.mupdf.MainActivity";
    private final DecimalFormat sevenSigDigits = new DecimalFormat("0.#######");
    private TabHost mTabHost;
    /**
     * Called when the activity is first created.
     */
    
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        
        appPrefs = new AppPreferences(getApplicationContext());
        setContentView(R.layout.settings);
        Resources res = getResources(); // Resource object to get Drawables

        mTabHost = getTabHost();
        
    Intent intent1 = new Intent(this, TabActivity1.class);           
    
    mTabHost.addTab(mTabHost.newTabSpec("tab_test1").setIndicator("Share Filter").setContent(intent1));        
   
    //mTabHost.addTab(mTabHost.newTabSpec("tab_test1").setIndicator("Primary Docs", res.getDrawable(R.drawable.ic_tab_main)).setContent(intent1));
    //mTabHost.addTab(mTabHost.newTabSpec("tab_test2").setIndicator("Accessorial", res.getDrawable(R.drawable.ic_tab_setup)).setContent(intent2));
    //mTabHost.addTab(mTabHost.newTabSpec("tab_test3").setIndicator("Damages").setContent(intent3));
    //mTabHost.addTab(mTabHost.newTabSpec("tab_test4").setIndicator("Dev Mode").setContent(intent4));
    
    mTabHost.setCurrentTab(0);     
    mTabHost.setBackgroundColor(Color.BLACK);
    mTabHost.getTabWidget().setBackgroundColor(Color.BLACK);
        
        // ToDo add your GUI initialization code here        
        //setContentView(R.layout.manage_database);
        
//        appPrefs = new AppPreferences(this.getApplicationContext());
        
//        final Button buttonSubmit = (Button) findViewById(R.id.buttonSubmit);
          /*      
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Context myContext=getApplicationContext();
                // Perform action on click   
                //read database row by row
                //submit form 
                //mark row in database
                try{
                    Intent service = new Intent(myContext, ExportDatabaseIntentService.class);
                    myContext.startService(service);                    
                }catch(Exception e){
                    Log.e(TAG, "Exception starting export service from ManageDatabaseActivity"+e);
                }                
                //doExport();
            }
        });
        /*
        final Button buttonClearDatabase = (Button) findViewById(R.id.clearDatabase);
                
        buttonClearDatabase.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click   
                //read database row by row
                //submit form 
                //mark row in database
                doClearDatabase();
            }
        });
        * 
        */
        
    }

    public void onClick(View arg0) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}    
