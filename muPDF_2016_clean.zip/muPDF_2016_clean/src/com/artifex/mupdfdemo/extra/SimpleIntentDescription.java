/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.artifex.mupdfdemo.extra;

import android.graphics.drawable.Drawable;
import android.widget.CheckBox;
import android.widget.ImageView;

/**
 *
 * @author Andrei
 */
public class SimpleIntentDescription {
    public String appName;
    public String packageName;
    public Drawable icon;
    public boolean checked;

		public SimpleIntentDescription(){
				// TODO Auto-generated constructor stub
			}

		public SimpleIntentDescription(String appName,String packageName, Drawable icon, boolean checked){
				this.appName = appName;
                                this.packageName = packageName;
				this.icon= icon;
				this.checked = checked;
			}

		@Override
		public String toString()
			{
				return this.packageName+":"+this.appName;
			}
    
}
