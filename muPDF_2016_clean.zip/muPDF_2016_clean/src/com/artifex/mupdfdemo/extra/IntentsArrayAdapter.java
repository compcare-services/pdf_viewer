package com.artifex.mupdfdemo.extra;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.artifex.mupdfdemo.AppPreferences;
import com.tssw.newmupdf.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.*;
import android.widget.CompoundButton.OnCheckedChangeListener;


public class IntentsArrayAdapter extends ArrayAdapter<SimpleIntentDescription> {
        private static final String tag = "IntentsArrayAdapter";
	private Context context;
	private ImageView icon;
	private TextView appName;
        private TextView packageName;
	private CheckBox checked;
        private String actionType="";

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }
	private List<SimpleIntentDescription> simpleIntentDescriptions = new ArrayList<SimpleIntentDescription>();
        private final AppPreferences appPrefs;

  	public IntentsArrayAdapter(Context context, int textViewResourceId,
			List<SimpleIntentDescription> objects) {
		super(context, textViewResourceId, objects);
		this.context = context;
		this.simpleIntentDescriptions = objects;
                Log.d(tag,"reading again!!!");
                appPrefs = new AppPreferences(context);
	} 
        public int getCount() {
		return this.simpleIntentDescriptions.size();
	}

	public SimpleIntentDescription getItem(int index) {
		return this.simpleIntentDescriptions.get(index);
	}
        
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		if (row == null) {
			// ROW INFLATION
			Log.d(tag, "Starting XML Row Inflation ... ");
			LayoutInflater inflater = (LayoutInflater) this.getContext()
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			row = inflater.inflate(R.layout.intents_listitem, parent, false);
			Log.d(tag, "Successfully completed XML Row Inflation!");
		}

                int pos=position;
		// Get item
		SimpleIntentDescription simpleIntentDescription = getItem(pos);
	
		// Get reference to ImageView 
		icon = (ImageView) row.findViewById(R.id.intent_icon);
		
                //set icon image
                icon.setImageDrawable(simpleIntentDescription.icon);


                
		// Get reference to TextView - package_name
		appName = (TextView) row.findViewById(R.id.intent_appname);
		
		//Set package name
		appName.setText(simpleIntentDescription.appName);
                
                
		// Get reference to TextView - package_name
		packageName = (TextView) row.findViewById(R.id.intent_packagename);
		
		//Set package name
		packageName.setText(simpleIntentDescription.packageName);
		/*
		// Set country icon usign File path
		String imgFilePath = ASSETS_DIR + country.resourceId;
		try {
			Bitmap bitmap = BitmapFactory.decodeStream(this.context.getResources().getAssets()
					.open(imgFilePath));
			countryIcon.setImageBitmap(bitmap);
		} catch (IOException e) {
			e.printStackTrace();
		}
		*/
		// Set country abbreviation
                // Get reference to CheckView - intent_ckeck
		checked = (CheckBox) row.findViewById(R.id.intent_checkbox);
		checked.setChecked(simpleIntentDescription.checked);
                //checked.setText(pos+":");
                checked.setTag(new Integer(pos));
                checked.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        CheckBox checkbox=(CheckBox)v;
                        Log.d(tag,"no: "+checkbox.getText().toString());
                        int pos=(Integer)checkbox.getTag();
                        SimpleIntentDescription temp = getItem(pos);
                        
                        if (checkbox.isChecked()) { 
                            Log.d(tag,"just became checked!!!, so let's check it also on position:"+pos+" extra: "+temp.toString());
                            //checkbox.setChecked(!checkbox.isChecked());
                            temp.checked=true;
                            simpleIntentDescriptions.set(pos, temp);
                            appPrefs.addPackageToList(actionType,simpleIntentDescriptions.get(pos).packageName);
                        } 
                        else 
                        { 
                            Log.d(tag,"just became unchecked!!!, so let's uncheck it also on position:"+pos+" extra: "+temp.toString());
                            //checkbox.setChecked(!checkbox.isChecked());
                            temp.checked=false;
                            simpleIntentDescriptions.set(pos, temp);
                            appPrefs.removePackageFromList(actionType,simpleIntentDescriptions.get(pos).packageName);
                        } 
                    } 
                });                 
                
		return row;
	}        
}
