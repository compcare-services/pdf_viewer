/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.artifex.mupdfdemo.extra;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;




import java.util.ArrayList;
import java.util.List;

import com.artifex.mupdfdemo.AppPreferences;
import com.tssw.newmupdf.R;

/**
 *
 * @author Andrei
 */
public class TabActivity1 extends Activity {
    private static final String TAG = new RuntimeException().getStackTrace()[0].getClassName();	
    protected AppPreferences appPrefs;
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        // ToDo add your GUI initialization code here        
        appPrefs = new AppPreferences(getApplicationContext());
        ArrayList<String> savedPackageList = appPrefs.getPackageList("SENDpackageList");
        for (int i=0;i<savedPackageList.size();i++){
            Log.d("tag",savedPackageList.get(i)+"");
        }
        setContentView(R.layout.tab1);
        List<SimpleIntentDescription> simpleIntentsDescriptionList =new ArrayList<SimpleIntentDescription>();//= countryParser.getList();
        
     //   List<Intent> targetedShareIntents = new ArrayList<Intent>();
        

        
        
        Intent shareIntent = new Intent(android.content.Intent.ACTION_SEND);
        shareIntent.setType("image/*");
        PackageManager pm = getPackageManager();
        List<ResolveInfo> resInfo = pm.queryIntentActivities(shareIntent, 0);
        if (!resInfo.isEmpty()){
            for (ResolveInfo resolveInfo : resInfo) {
                String appName = resolveInfo.activityInfo.loadLabel(pm).toString();
                String packageName = resolveInfo.activityInfo.packageName;
                
                Drawable packageIcon = resolveInfo.activityInfo.loadIcon(pm);
                boolean checked=false;
                if (savedPackageList.contains(packageName))
                    checked=true;
                simpleIntentsDescriptionList.add(new SimpleIntentDescription(appName,packageName,packageIcon,checked));
                
                //appPrefs.addPackageToList(packageName);
            }
            
            
            Intent printIntent = new Intent(Intent.ACTION_SEND);
            printIntent.setPackage("com.google.android.apps.cloudprint");
             resInfo = pm.queryIntentActivities(printIntent, 0);
//            printIntent.putExtra(Intent.EXTRA_TITLE, �Print Test Title�);
//            printIntent.putExtra(Intent.EXTRA_STREAM, uri);            
            
            if (resInfo!=null && resInfo.size()>0){
            	Log.d(TAG, "printing available!!!");
            	for (ResolveInfo resolveInfo : resInfo) {
                    String appName = (String) resolveInfo.activityInfo.loadLabel(pm);
                    Log.d(TAG,"activity found: "+appName);
                    String packageName = resolveInfo.activityInfo.packageName;
                    
                    Drawable packageIcon = resolveInfo.activityInfo.loadIcon(pm);
                    boolean checked=false;
                    if (savedPackageList.contains(packageName))
                        checked=true;
                    simpleIntentsDescriptionList.add(new SimpleIntentDescription(appName,packageName,packageIcon,checked));
                    
                    //appPrefs.addPackageToList(packageName);
                }            	
            }else{
            	Log.d(TAG, "printing NOT available!!!");
            }
            
        }
		
		
		// Create a customized ArrayAdapter
		IntentsArrayAdapter adapter = new IntentsArrayAdapter(
				getApplicationContext(), R.layout.intents_listitem, simpleIntentsDescriptionList);
		adapter.setActionType("SENDpackageList");
		// Get reference to ListView holder
		ListView lv = (ListView) this.findViewById(R.id.intentsList);
		
		// Set the ListView adapter
		lv.setAdapter(adapter);        

    }
}
