package com.artifex.mupdfdemo.extra;

import java.text.SimpleDateFormat;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;



import com.tssw.newmupdf.R;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.widget.TextView;

public class AboutActivity extends Activity
{


    
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        try{
            ApplicationInfo ai = getPackageManager().getApplicationInfo(getPackageName(), 0);
            ZipFile zf = new ZipFile(ai.sourceDir);
            ZipEntry ze = zf.getEntry("classes.dex");
            long time = ze.getTime();
            zf.close();
            String s = SimpleDateFormat.getInstance().format(new java.util.Date(time));
            TextView app_ver =(TextView)findViewById(R.id.app_ver);
            app_ver.setText(s);
         }catch(Exception e){
         }       
    }    
    
}


