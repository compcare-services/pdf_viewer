package com.artifex.mupdfdemo.utils;

public class NeededPerm {
    String permissionName;
    int requestCode;
    Boolean allowWithout;
    String message;
    Boolean isPermissionGranted;

    public NeededPerm() {
    }

    public NeededPerm(String permissionName, int requestCode, Boolean allowWithout, String message, Boolean isPermissionGranted) {
        this.permissionName = permissionName;
        this.requestCode = requestCode;
        this.allowWithout = allowWithout;
        this.message = message;
        this.isPermissionGranted = isPermissionGranted;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public int getRequestCode() {
        return requestCode;
    }

    public void setRequestCode(int requestCode) {
        this.requestCode = requestCode;
    }

    public Boolean getAllowWithout() {
        return allowWithout;
    }

    public void setAllowWithout(Boolean allowWithout) {
        this.allowWithout = allowWithout;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getPermissionGranted() {
        return isPermissionGranted;
    }

    public void setPermissionGranted(Boolean permissionGranted) {
        isPermissionGranted = permissionGranted;
    }

    @Override
    public String toString() {
        return "NeededPerm{" +
                "permissionName='" + permissionName + '\'' +
                ", requestCode=" + requestCode +
                ", allowWithout=" + allowWithout +
                ", message='" + message + '\'' +
                '}';
    }
}
