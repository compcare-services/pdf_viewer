package com.artifex.mupdfdemo;

import android.Manifest;
import android.R.drawable;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.text.Editable;
import android.text.Layout;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Surface;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewAnimator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import com.artifex.mupdfdemo.utils.NeededPerm;
import com.artifex.mupdfdemo.utils.ZipUtils;
import com.tssw.newmupdf.R;

class ThreadPerTaskExecutor implements Executor {
	public void execute(Runnable r) {
		new Thread(r).start();
	}
}

@SuppressLint("NewApi")
public class MuPDFActivity extends FragmentActivity implements FilePicker.FilePickerSupport
{
	/* The core rendering instance */
	enum TopBarMode {Main, Search, Annot, Delete, More, Accept};
	enum AcceptMode {Highlight, Underline, StrikeOut, Ink, CopyText};

	private static final String TAG = new RuntimeException().getStackTrace()[0].getClassName();
	
	final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
	
	HashMap<String, NeededPerm> allPermissions = new HashMap<String, NeededPerm>() {{
	//	put(Manifest.permission.ACCESS_FINE_LOCATION, (new NeededPerm(Manifest.permission.ACCESS_FINE_LOCATION, 101, false, "Location", false)));
		put(Manifest.permission.READ_EXTERNAL_STORAGE, (new NeededPerm(Manifest.permission.READ_EXTERNAL_STORAGE, 102, false, "Storage", false)));
		put(Manifest.permission.WRITE_EXTERNAL_STORAGE, (new NeededPerm(Manifest.permission.WRITE_EXTERNAL_STORAGE, 103, false, "Storage", false)));
	//	put(Manifest.permission.CAMERA, (new NeededPerm(Manifest.permission.CAMERA, 104, false, "Camera", false)));
	   // put(Manifest.permission.CALL_PHONE, (new NeededPerm(Manifest.permission.CALL_PHONE, 104, true, "Phone", false)));
	   // put(Manifest.permission.READ_CONTACTS, (new NeededPerm(Manifest.permission.READ_CONTACTS, 105, true, "Contacts", false)));
	}};	

	
	private final int    OUTLINE_REQUEST=0;
	private final int    PRINT_REQUEST=1;
	private final int    FILEPICK_REQUEST=2;
	private final int    PROOF_REQUEST=3;
	private MuPDFCore    core;
	private String       mFileName;
	private MuPDFReaderView mDocView;
	private View         mButtonsView;
	private boolean      mButtonsVisible;
	private EditText     mPasswordView;
	private TextView     mFilenameView;
	private SeekBar      mPageSlider;
	private int          mPageSliderRes;
	private TextView     mPageNumberView;
	private TextView     mInfoView;
	private ImageButton  mSearchButton;
	private ImageButton  mReflowButton;
	private ImageButton  mOutlineButton;
	private ImageButton	mMoreButton;
	private TextView     mAnnotTypeText;
	private ImageButton mAnnotButton;
	private ViewAnimator mTopBarSwitcher;
	private ImageButton  mLinkButton;
	private TopBarMode   mTopBarMode = TopBarMode.Main;
	private AcceptMode   mAcceptMode;
	private ImageButton  mSearchBack;
	private ImageButton  mSearchFwd;
	private EditText     mSearchText;
	private SearchTask   mSearchTask;
	private ImageButton  mProofButton;
	private ImageButton  mSepsButton;
	private AlertDialog.Builder mAlertBuilder;
	private boolean    mLinkHighlight = false;
	private final Handler mHandler = new Handler();
	private boolean mAlertsActive= false;
	private boolean mReflow = false;
	private AsyncTask<Void,Void,MuPDFAlert> mAlertTask;
	private AlertDialog mAlertDialog;
	private FilePicker mFilePicker;
	private String     mProofFile;
	private boolean mSepEnabled[][];

	private boolean isSignatureAvailable;

	private String path;

	private com.artifex.mupdfdemo.AppPreferences appPrefs;

	private Uri localUri;

	//private String permissionMode;

	private ImageButton inkButton;

	private ImageButton magicButton;

	private String permissionMode;

	static private AlertDialog.Builder gAlertBuilder;
	static public AlertDialog.Builder getAlertBuilder() {return gAlertBuilder;}

	public void createAlertWaiter() {
		mAlertsActive = true;
		// All mupdf library calls are performed on asynchronous tasks to avoid stalling
		// the UI. Some calls can lead to javascript-invoked requests to display an
		// alert dialog and collect a reply from the user. The task has to be blocked
		// until the user's reply is received. This method creates an asynchronous task,
		// the purpose of which is to wait of these requests and produce the dialog
		// in response, while leaving the core blocked. When the dialog receives the
		// user's response, it is sent to the core via replyToAlert, unblocking it.
		// Another alert-waiting task is then created to pick up the next alert.
		if (mAlertTask != null) {
			mAlertTask.cancel(true);
			mAlertTask = null;
		}
		if (mAlertDialog != null) {
			mAlertDialog.cancel();
			mAlertDialog = null;
		}
		mAlertTask = new AsyncTask<Void,Void,MuPDFAlert>() {

			@Override
			protected MuPDFAlert doInBackground(Void... arg0) {
				if (!mAlertsActive)
					return null;

				return core.waitForAlert();
			}

			@Override
			protected void onPostExecute(final MuPDFAlert result) {
				// core.waitForAlert may return null when shutting down
				if (result == null)
					return;
				final MuPDFAlert.ButtonPressed pressed[] = new MuPDFAlert.ButtonPressed[3];
				for(int i = 0; i < 3; i++)
					pressed[i] = MuPDFAlert.ButtonPressed.None;
				DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						mAlertDialog = null;
						if (mAlertsActive) {
							int index = 0;
							switch (which) {
							case AlertDialog.BUTTON1: index=0; break;
							case AlertDialog.BUTTON2: index=1; break;
							case AlertDialog.BUTTON3: index=2; break;
							}
							result.buttonPressed = pressed[index];
							// Send the user's response to the core, so that it can
							// continue processing.
							core.replyToAlert(result);
							// Create another alert-waiter to pick up the next alert.
							createAlertWaiter();
						}
					}
				};
				mAlertDialog = mAlertBuilder.create();
				mAlertDialog.setTitle(result.title);
				mAlertDialog.setMessage(result.message);
				switch (result.iconType)
				{
				case Error:
					break;
				case Warning:
					break;
				case Question:
					break;
				case Status:
					break;
				}
				switch (result.buttonGroupType)
				{
				case OkCancel:
					mAlertDialog.setButton(AlertDialog.BUTTON2, getString(R.string.cancel), listener);
					pressed[1] = MuPDFAlert.ButtonPressed.Cancel;
				case Ok:
					mAlertDialog.setButton(AlertDialog.BUTTON1, getString(R.string.okay), listener);
					pressed[0] = MuPDFAlert.ButtonPressed.Ok;
					break;
				case YesNoCancel:
					mAlertDialog.setButton(AlertDialog.BUTTON3, getString(R.string.cancel), listener);
					pressed[2] = MuPDFAlert.ButtonPressed.Cancel;
				case YesNo:
					mAlertDialog.setButton(AlertDialog.BUTTON1, getString(R.string.yes), listener);
					pressed[0] = MuPDFAlert.ButtonPressed.Yes;
					mAlertDialog.setButton(AlertDialog.BUTTON2, getString(R.string.no), listener);
					pressed[1] = MuPDFAlert.ButtonPressed.No;
					break;
				}
				mAlertDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
					public void onCancel(DialogInterface dialog) {
						mAlertDialog = null;
						if (mAlertsActive) {
							result.buttonPressed = MuPDFAlert.ButtonPressed.None;
							core.replyToAlert(result);
							createAlertWaiter();
						}
					}
				});

				mAlertDialog.show();
			}
		};

		mAlertTask.executeOnExecutor(new ThreadPerTaskExecutor());
	}

	public void destroyAlertWaiter() {
		mAlertsActive = false;
		if (mAlertDialog != null) {
			mAlertDialog.cancel();
			mAlertDialog = null;
		}
		if (mAlertTask != null) {
			mAlertTask.cancel(true);
			mAlertTask = null;
		}
	}

	private MuPDFCore openFile(String path)
	{
		int lastSlashPos = path.lastIndexOf('/');
		mFileName = new String(lastSlashPos == -1
					? path
					: path.substring(lastSlashPos+1));
		System.out.println("Trying to open " + path);
		try
		{
			core = new MuPDFCore(this, path);
			// New file: drop the old outline data
			OutlineActivityData.set(null);
		}
		catch (Exception e)
		{
			System.out.println(e);
			return null;
		}
		catch (java.lang.OutOfMemoryError e)
		{
			//  out of memory is not an Exception, so we catch it separately.
			System.out.println(e);
			return null;
		}
		return core;
	}

	private MuPDFCore openBuffer(byte buffer[], String magic)
	{
		System.out.println("Trying to open byte buffer");
		try
		{
			core = new MuPDFCore(this, buffer, magic);
			// New file: drop the old outline data
			OutlineActivityData.set(null);
		}
		catch (Exception e)
		{
			System.out.println(e);
			return null;
		}
		return core;
	}

	//  determine whether the current activity is a proofing activity.
	public boolean isProofing()
	{
		String format = core.fileFormat();
		return (format.equals("GPROOF"));
	}

	
	public String extractText(){
		String word="";
		TextWord[][] textWord = core.textLines(mDocView.getDisplayedViewIndex());
		 int z, j;
	
		for (z = 0; z < textWord.length; z++) {
		    for (j = 0; j < textWord[z].length; j++) {
		        word = word + textWord[z][j].w + " ";
		    }
		    word=word+"\n";
		}
		return word;
	}	
	
	
	
	private String getRealPathFromURI(Uri contentURI) {
	    String result;
	    Cursor cursor = getContentResolver().query(contentURI, null, null, null, null);
	    if (cursor == null) { //checking
	        result = contentURI.getPath();
	    } else { 
	        cursor.moveToFirst(); 
	        int idx = cursor.getColumnIndex(MediaStore.Files.FileColumns.DATA); 
	        result = cursor.getString(idx);
	        cursor.close();
	    }
	    return result;
	}
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(final Bundle savedInstanceState)
	{
		//setTheme(R.style.AppBaseTheme);
		super.onCreate(savedInstanceState);
		checkAllPermissions();
		
		ActionBar actionBar = getActionBar(); 
		//actionBar.hide();
	    //requestWindowFeature(Window.FEATURE_NO_TITLE);
	    // hide statusbar of Android
	    // could also be done later
	   // getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
	    //        WindowManager.LayoutParams.FLAG_FULLSCREEN);		
		Context context = getApplicationContext();
		//permissionMode= "rw";
		
	       setHasPermanentMenuKey(context,false);
	        appPrefs = new AppPreferences(context);
	        
	                
	        //init defaults:
	        ArrayList<String> savedPackageList = appPrefs.getPackageList("SENDpackageList");
	        if (savedPackageList==null || savedPackageList.size()==0){
	        	appPrefs.addPackageToList("SENDpackageList", "com.google.android.gm");
	        }
        

		
		mAlertBuilder = new AlertDialog.Builder(this);
		gAlertBuilder = mAlertBuilder;  //  keep a static copy of this that other classes can use

		if (core == null) {
			core = (MuPDFCore)getLastCustomNonConfigurationInstance();

			if (savedInstanceState != null && savedInstanceState.containsKey("FileName")) {
				mFileName = savedInstanceState.getString("FileName");
			}
			
			if (savedInstanceState != null && savedInstanceState.containsKey("path")) {
				path = savedInstanceState.getString("path");
				Log.d(TAG,"recovering the path: "+path);
			}			
			
		}
        
		if (core == null) {
			Intent intent = getIntent();
			byte buffer[] = null;
			
			if (Intent.ACTION_VIEW.equals(intent.getAction())) {
				
				Uri uri = intent.getData();
				System.out.println("URI to open is: " + uri);
				
				/*
                final Bundle extras = intent.getExtras();
                Parcelable mFileStreamUri = null;
				if (extras != null && extras.containsKey(Intent.EXTRA_STREAM))
                	mFileStreamUri = extras.getParcelable(Intent.EXTRA_STREAM);
				
				//String realPath = getRealPathFromURI(uri);
				Log.d(TAG,"realPath should be: "+mFileStreamUri.toString());
				*/
				
				permissionMode = "rw";
				ParcelFileDescriptor pfd = null;
				ContentResolver resolver = context.getContentResolver();
				try {
					if ( PackageManager.PERMISSION_GRANTED == context.checkCallingOrSelfUriPermission(uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION)){
						Log.d(TAG,"write: true");
						//permissionMode= "rw";
					}else{ 
						Log.d(TAG,"write: false");
						//permissionMode= "r";
					}
					if ( PackageManager.PERMISSION_GRANTED == context.checkCallingOrSelfUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)){
						Log.d(TAG,"read: true");
						//permissionMode= "r";
					}else {
						//permissionMode= "";
						Log.d(TAG,"read: false");
					}

					pfd = resolver.openFileDescriptor(uri,"rw");
					pfd.close();
				} catch (FileNotFoundException e1) {
					Log.e(TAG, "FileNotFoundException in pfd",e1);
				} catch (SecurityException e) {
					Log.e(TAG, "Can't open this in Write mode!!!!",e);
					try {
						pfd = resolver.openFileDescriptor(uri,"r");
						pfd.close();
						permissionMode = "r";
					}catch (SecurityException e1) {
						Log.e(TAG, "Can't open this in Read mode!!!!",e1);
					} catch (FileNotFoundException e1) {
						Log.e(TAG, "FileNotFoundException in pfd",e1);
					} catch (IOException e1) {
					}
				} catch (IOException e) {
				}finally{
				}
				
				Log.d(TAG, "this file has access as: "+permissionMode);				
				
				//hack to detect old file behavior instead of content 
				
				String magicPath = "/external_files/Download/";
				if (uri.toString().startsWith("content://") && uri.toString().contains(magicPath)) {
					if (new File(path).exists()){
						Log.d(TAG,"path should be: "+path);
						uri = Uri.parse("file://"+path);
					}
				}
				
				magicPath = "/external_files";
				if (uri.toString().startsWith("content://") && uri.toString().contains(magicPath)) {
					String external_storage_folder = getExternalFilesDir(null).getAbsolutePath();
					String prefix = external_storage_folder.substring(0,external_storage_folder.indexOf("/Android/data/"+getPackageName()));
					String content = uri.toString();
					String path = prefix+content.substring(content.indexOf(magicPath)+magicPath.length());
					if (new File(path).exists()){
						Log.d(TAG,"path should be: "+path);
						uri = Uri.parse("file://"+path);
					}
				}
				if (uri.toString().startsWith("content://")) {
					localUri= uri;
					String reason = null;
					try {
						InputStream is = getContentResolver().openInputStream(uri);
						int len = is.available();
						buffer = new byte[len];
						is.read(buffer, 0, len);
						is.close();
					}
					catch (java.lang.OutOfMemoryError e) {
						System.out.println("Out of memory during buffer reading");
						reason = e.toString();
					}
					catch (Exception e) {
						System.out.println("Exception reading from stream: " + e);

						// Handle view requests from the Transformer Prime's file manager
						// Hopefully other file managers will use this same scheme, if not
						// using explicit paths.
						// I'm hoping that this case below is no longer needed...but it's
						// hard to test as the file manager seems to have changed in 4.x.
						try {
							Cursor cursor = getContentResolver().query(uri, new String[]{"_data"}, null, null, null);
							if (cursor.moveToFirst()) {
								String str = cursor.getString(0);
								if (str == null) {
									reason = "Couldn't parse data in intent";
								}
								else {
									uri = Uri.parse(str);
								}
							}
						}
						catch (Exception e2) {
							System.out.println("Exception in Transformer Prime file manager code: " + e2);
							reason = e2.toString();
						}
					}
					if (reason != null) {
						buffer = null;
						Resources res = getResources();
						AlertDialog alert = mAlertBuilder.create();
						setTitle(String.format(res.getString(R.string.cannot_open_document_Reason), reason));
						alert.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.dismiss),
								new DialogInterface.OnClickListener() {
									public void onClick(DialogInterface dialog, int which) {
										finish();
									}
								});
						alert.show();
						return;
					}
				}
				if (buffer != null) {
					//patching path BEGIN: some apps sends the path to the file as content...
					path = Uri.decode(uri.getEncodedPath());
					if (path == null) {
						path = uri.toString();
					}
					if (path != null && path.startsWith("/filesystem/")){
						path= path.substring("/filesystem".length());
					}
					//patching path END
					core = openBuffer(buffer, intent.getType());
				} else {
					path = Uri.decode(uri.getEncodedPath());
					if (path == null) {
						path = uri.toString();
					}
					
					core = openFile(path);
				}
				SearchTaskResult.set(null);
			}
			if (core != null && core.needsPassword()) {
				requestPassword(savedInstanceState);
				return;
			}
			if (core != null && core.countPages() == 0)
			{
				core = null;
			}
		}
		if (core == null)
		{
			AlertDialog alert = mAlertBuilder.create();
			alert.setTitle(R.string.cannot_open_document);
			alert.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.dismiss),
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							finish();
						}
					});
			alert.setOnCancelListener(new OnCancelListener() {

				@Override
				public void onCancel(DialogInterface dialog) {
					finish();
				}
			});
			alert.show();
			return;
		}

		createUI(savedInstanceState);

		//  hide the proof button if this file can't be proofed
		if (!core.canProof()) {
			mProofButton.setVisibility(View.INVISIBLE);
		}

		if (isProofing()) {

			//  start the activity with a new array
			mSepEnabled = null;

			//  show the separations button
			mSepsButton.setVisibility(View.VISIBLE);

			//  hide some other buttons
			mLinkButton.setVisibility(View.INVISIBLE);
			mReflowButton.setVisibility(View.INVISIBLE);
			mOutlineButton.setVisibility(View.INVISIBLE);
			mSearchButton.setVisibility(View.INVISIBLE);
			mMoreButton.setVisibility(View.INVISIBLE);
		}
		else {
			//  hide the separations button
			mSepsButton.setVisibility(View.INVISIBLE);
		}

		
///////////////////////////////////////////////////////////////////
		// ShareItem
		Intent intent = getIntent();

		if (Intent.ACTION_VIEW.equals(intent.getAction())) {

			//Intent.EXTRA_INITIAL_INTENTS
			//Intent[] sharedIntents = (Intent[]) intent.getParcelableArrayExtra(Intent.EXTRA_INITIAL_INTENTS);
			//for (Intent sharedIntent :sharedIntents){
			//	Log.d(TAG,"sharedIntent: "+sharedIntent.getAction()+" - "+sharedIntent.getStringExtra(android.content.Intent.EXTRA_SUBJECT));
			//}
			
			ImageButton shareButton = (ImageButton) mButtonsView.findViewById(R.id.shareButton);

		}
		
	}

	public void requestPassword(final Bundle savedInstanceState) {
		mPasswordView = new EditText(this);
		mPasswordView.setInputType(EditorInfo.TYPE_TEXT_VARIATION_PASSWORD);
		mPasswordView.setTransformationMethod(new PasswordTransformationMethod());

		AlertDialog alert = mAlertBuilder.create();
		alert.setTitle(R.string.enter_password);
		alert.setView(mPasswordView);
		alert.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.okay),
				new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						if (core.authenticatePassword(mPasswordView.getText().toString())) {
							createUI(savedInstanceState);
						} else {
							requestPassword(savedInstanceState);
						}
					}
				});
		alert.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.cancel),
				new DialogInterface.OnClickListener() {

			public void onClick(DialogInterface dialog, int which) {
				finish();
			}
		});
		alert.show();
	}

	public void createUI(Bundle savedInstanceState) {
		if (core == null)
			return;

		// Now create the UI.
		// First create the document view
		mDocView = new MuPDFReaderView(this) {
			@Override
			protected void onMoveToChild(int i) {
				if (core == null)
					return;

				mPageNumberView.setText(String.format("%d / %d", i + 1,
						core.countPages()));
				mPageSlider.setMax((core.countPages() - 1) * mPageSliderRes);
				mPageSlider.setProgress(i * mPageSliderRes);
				super.onMoveToChild(i);
			}

			@Override
			protected void onTapMainDocArea() {
				if (!mButtonsVisible) {
					showButtons();
				} else {
					if (mTopBarMode == TopBarMode.Main)
						hideButtons();
				}
			}

			@Override
			protected void onDocMotion() {
				hideButtons();
			}

			@Override
			protected void onHit(Hit item) {
				switch (mTopBarMode) {
				case Annot:
					if (item == Hit.Annotation) {
						showButtons();
						mTopBarMode = TopBarMode.Delete;
						mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
					}
					break;
				case Delete:
					mTopBarMode = TopBarMode.Annot;
					mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
				// fall through
				default:
					// Not in annotation editing mode, but the pageview will
					// still select and highlight hit annotations, so
					// deselect just in case.
					MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
					if (pageView != null)
						pageView.deselectAnnotation();
					break;
				}
			}
		};
		mDocView.setAdapter(new MuPDFPageAdapter(this, this, core));

		mSearchTask = new SearchTask(this, core) {
			@Override
			protected void onTextFound(SearchTaskResult result) {
				SearchTaskResult.set(result);
				// Ask the ReaderView to move to the resulting page
				mDocView.setDisplayedViewIndex(result.pageNumber);
				// Make the ReaderView act on the change to SearchTaskResult
				// via overridden onChildSetup method.
				mDocView.resetupChildren();
			}
		};

		// Make the buttons overlay, and store all its
		// controls in variables
		makeButtonsView();

		// Set up the page slider
		int smax = Math.max(core.countPages()-1,1);
		mPageSliderRes = ((10 + smax - 1)/smax) * 2;

		// Set the file-name text
		mFilenameView.setText(mFileName);

		// Activate the seekbar
		mPageSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			public void onStopTrackingTouch(SeekBar seekBar) {
				mDocView.setDisplayedViewIndex((seekBar.getProgress()+mPageSliderRes/2)/mPageSliderRes);
			}

			public void onStartTrackingTouch(SeekBar seekBar) {}

			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				updatePageNumView((progress+mPageSliderRes/2)/mPageSliderRes);
			}
		});
/*
		// Activate the search-preparing button
		mSearchButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				searchModeOn();
			}
		});
*/
/*
		// Activate the reflow button
		mReflowButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				toggleReflow();
			}
		});
*/
		if (core.fileFormat().startsWith("PDF") && core.isUnencryptedPDF() && !core.wasOpenedFromBuffer())
		{
			mAnnotButton.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					mTopBarMode = TopBarMode.Annot;
					mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
				}
			});
		}
		else
		{
			mAnnotButton.setVisibility(View.GONE);
		}

		// Search invoking buttons are disabled while there is no text specified
		mSearchBack.setEnabled(false);
		mSearchFwd.setEnabled(false);
		mSearchBack.setColorFilter(Color.argb(255, 128, 128, 128));
		mSearchFwd.setColorFilter(Color.argb(255, 128, 128, 128));

		// React to interaction with the text widget
		mSearchText.addTextChangedListener(new TextWatcher() {

			public void afterTextChanged(Editable s) {
				boolean haveText = s.toString().length() > 0;
				setButtonEnabled(mSearchBack, haveText);
				setButtonEnabled(mSearchFwd, haveText);

				// Remove any previous search results
				if (SearchTaskResult.get() != null && !mSearchText.getText().toString().equals(SearchTaskResult.get().txt)) {
					SearchTaskResult.set(null);
					mDocView.resetupChildren();
				}
			}
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {}
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {}
		});

		//React to Done button on keyboard
		mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				if (actionId == EditorInfo.IME_ACTION_DONE)
					search(1);
				return false;
			}
		});

		mSearchText.setOnKeyListener(new View.OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER)
					search(1);
				return false;
			}
		});

		// Activate search invoking buttons
		mSearchBack.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				search(-1);
			}
		});
		mSearchFwd.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				search(1);
			}
		});

		/*
		mLinkButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				setLinkHighlight(!mLinkHighlight);
			}
		});
		*/
		/*
		if (core.hasOutline()) {
			mOutlineButton.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					OutlineItem outline[] = core.getOutline();
					if (outline != null) {
						OutlineActivityData.get().items = outline;
						Intent intent = new Intent(MuPDFActivity.this, OutlineActivity.class);
						startActivityForResult(intent, OUTLINE_REQUEST);
					}
				}
			});
		} else {
			mOutlineButton.setVisibility(View.GONE);
		}
		 */
		// Reenstate last state if it was recorded
		SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
		mDocView.setDisplayedViewIndex(prefs.getInt("page"+mFileName, 0));

		if (savedInstanceState == null || !savedInstanceState.getBoolean("ButtonsHidden", false))
			showButtons();
		/*
		if(savedInstanceState != null && savedInstanceState.getBoolean("SearchMode", false))
			searchModeOn();
		
		if(savedInstanceState != null && savedInstanceState.getBoolean("ReflowMode", false))
			reflowModeSet(true);
		 */
		
		// Stick the document view and the buttons overlay into a parent view
		RelativeLayout layout = new RelativeLayout(this);
		layout.addView(mDocView);
		layout.addView(mButtonsView);
		setContentView(layout);

		if (isProofing()) {
			//  go to the current page
			int currentPage = getIntent().getIntExtra("startingPage", 0);
			mDocView.setDisplayedViewIndex(currentPage);
		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case OUTLINE_REQUEST:
			if (resultCode >= 0)
				mDocView.setDisplayedViewIndex(resultCode);
			break;
		case PRINT_REQUEST:
			if (resultCode == RESULT_CANCELED)
				showInfo(getString(R.string.print_failed));
			break;
		case FILEPICK_REQUEST:
			if (mFilePicker != null && resultCode == RESULT_OK)
				mFilePicker.onPick(data.getData());
		case PROOF_REQUEST:
			//  we're returning from a proofing activity

			if (mProofFile != null)
			{
				core.endProof(mProofFile);
				mProofFile = null;
			}

			//  return the top bar to default
			mTopBarMode = TopBarMode.Main;
			mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	public Object onRetainCustomNonConfigurationInstance()
	{
		MuPDFCore mycore = core;
		core = null;
		return mycore;
	}

	/*
	private void reflowModeSet(boolean reflow)
	{
		mReflow = reflow;
		mDocView.setAdapter(mReflow ? new MuPDFReflowAdapter(this, core) : new MuPDFPageAdapter(this, this, core));
		mReflowButton.setColorFilter(mReflow ? Color.argb(0xFF, 172, 114, 37) : Color.argb(0xFF, 255, 255, 255));
		setButtonEnabled(mAnnotButton, !reflow);
		setButtonEnabled(mSearchButton, !reflow);
		if (reflow) setLinkHighlight(false);
		setButtonEnabled(mLinkButton, !reflow);
		setButtonEnabled(mMoreButton, !reflow);
		mDocView.refresh(mReflow);
	}
	 */
	/*
	private void toggleReflow() {
		reflowModeSet(!mReflow);
		showInfo(mReflow ? getString(R.string.entering_reflow_mode) : getString(R.string.leaving_reflow_mode));
	}
	 */
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);

		if (mFileName != null && mDocView != null) {
			outState.putString("FileName", mFileName);

			// Store current page in the prefs against the file name,
			// so that we can pick it up each time the file is loaded
			// Other info is needed only for screen-orientation change,
			// so it can go in the bundle
			SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
			SharedPreferences.Editor edit = prefs.edit();
			edit.putInt("page"+mFileName, mDocView.getDisplayedViewIndex());
			edit.commit();
			// fix for rotation losing track of the name
			edit.putString("path", path);
			edit.commit();
		}
		
		if (path != null && mDocView != null) {
			outState.putString("path", path);
		}		

		if (!mButtonsVisible)
			outState.putBoolean("ButtonsHidden", true);

		if (mTopBarMode == TopBarMode.Search)
			outState.putBoolean("SearchMode", true);

		if (mReflow)
			outState.putBoolean("ReflowMode", true);
	}

	@Override
	protected void onPause() {
		super.onPause();

		if (mSearchTask != null)
			mSearchTask.stop();

		if (mFileName != null && mDocView != null) {
			SharedPreferences prefs = getPreferences(Context.MODE_PRIVATE);
			SharedPreferences.Editor edit = prefs.edit();
			edit.putInt("page"+mFileName, mDocView.getDisplayedViewIndex());
			edit.commit();
		}
	}

	public void onDestroy()
	{
		if (mDocView != null) {
			mDocView.applyToChildren(new ReaderView.ViewMapper() {
				void applyToView(View view) {
					((MuPDFView)view).releaseBitmaps();
				}
			});
		}
		if (core != null)
			core.onDestroy();
		if (mAlertTask != null) {
			mAlertTask.cancel(true);
			mAlertTask = null;
		}
		core = null;
		super.onDestroy();
	}
	
	public static void saveLogcatToFile(String folder) {    
	    String fileName = "logcat_"+System.currentTimeMillis()+".txt";
	    File outputFile = new File(folder,fileName);
	    try {
			@SuppressWarnings("unused")
			Process process = Runtime.getRuntime().exec("logcat -f "+outputFile.getAbsolutePath());

		} catch (IOException e) {
			Log.e(TAG, "Failed to write logcat...");
			e.printStackTrace();
		}
	}	
	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }        
     
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        
        switch (item.getItemId()) {           
            case R.id.about: {  
                Intent myIntent = new Intent(getApplicationContext(), com.artifex.mupdfdemo.extra.AboutActivity.class);
                startActivity(myIntent);
                break;
            }             
            case R.id.openSettings: {  
                Intent myIntent = new Intent(getApplicationContext(), com.artifex.mupdfdemo.extra.SettingsActivity.class);
                startActivity(myIntent);
                break;
            }  
            case R.id.prepareBugReport: {                
	       	 	saveLogcatToFile(getApplicationContext().getFilesDir().getAbsolutePath());
	       	 	break;
			}        
	        case R.id.zipBugReport: {
				String zipFile = Environment.getExternalStorageDirectory()+File.separator+"pdfviewer_bug_report.zip";
				//String databaseName = getApplicationContext().getDatabasePath(DatabaseHelper.DATABASE_NAME).getAbsolutePath();
				ArrayList<String> files = null;//new ArrayList<String>();
				files = (ArrayList<String>)ZipUtils.listf(getApplicationContext().getFilesDir().getAbsolutePath());
				//files.add(databaseName);
				

				String[] listArray=(String[]) files.toArray(new String[files.size()]);
				//String[] listArray = (String[]) Arrays.asList(files).toArray(files);
				//listArray.get
				ZipUtils zipper=new ZipUtils(listArray, zipFile);
				zipper.zip();
				
				List<Intent> targetedEditIntents = new ArrayList<Intent>();
	            Intent sendtoIntent = new Intent(android.content.Intent.ACTION_SENDTO);
	            sendtoIntent.setData(Uri.parse("mailto:" + "tssw.tabletsupport@compcareservices.com"));

	            List<ResolveInfo> resInfo = getPackageManager().queryIntentActivities(sendtoIntent, 0);
	            if (!resInfo.isEmpty()){
	                for (ResolveInfo resolveInfo : resInfo) {
	                	String packageName = resolveInfo.activityInfo.packageName;
	                	Intent targetedEditIntent = new Intent(android.content.Intent.ACTION_SEND);
	                	targetedEditIntent.setPackage(packageName);
	                	targetedEditIntent.setData(Uri.parse("mailto:" + "tssw.tabletsupport@compcareservices.com"));
	                    String subject="PdfViewer Bug Report from: "+appPrefs.getSCAC()+"-"+appPrefs.getUserID();
	                    targetedEditIntent.setType("text/plain");
	                    targetedEditIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"tssw.tabletsupport@compcareservices.com"});
	                    targetedEditIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(zipFile)));
	                    targetedEditIntent.putExtra(Intent.EXTRA_SUBJECT, subject);    
	                    targetedEditIntent.putExtra(Intent.EXTRA_TEXT, "Describe the bug here: \n");
	                    //targetedEditIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	                    targetedEditIntents.add(targetedEditIntent);
	                }
	            }
	            if (targetedEditIntents.size()>0){
	                Intent chooserIntent = Intent.createChooser(targetedEditIntents.remove(0), "Select email application:");
	                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetedEditIntents.toArray(new Parcelable[]{}));
	                startActivity(chooserIntent);
	            }                        
	            break;
	        }            
            /*                
                        case R.id.save: {  
                        * //break
                        }        
            */
        }
        return true;
    }
    
	private void setButtonEnabled(ImageButton button, boolean enabled) {
		button.setEnabled(enabled);
		button.setColorFilter(enabled ? Color.argb(255, 255, 255, 255) : Color.argb(255, 128, 128, 128));
	}

	/*
	private void setLinkHighlight(boolean highlight) {
		mLinkHighlight = highlight;
		// LINK_COLOR tint
		mLinkButton.setColorFilter(highlight ? Color.argb(0xFF, 172, 114, 37) : Color.argb(0xFF, 255, 255, 255));
		// Inform pages of the change.
		mDocView.setLinksEnabled(highlight);
	}
*/
	private void showButtons() {
		if (core == null)
			return;
		if (!mButtonsVisible) {
			mButtonsVisible = true;
			// Update page number text and slider
			int index = mDocView.getDisplayedViewIndex();
			updatePageNumView(index);
			mPageSlider.setMax((core.countPages()-1)*mPageSliderRes);
			mPageSlider.setProgress(index * mPageSliderRes);
			if (mTopBarMode == TopBarMode.Search) {
				mSearchText.requestFocus();
				showKeyboard();
			}

			Animation anim = new TranslateAnimation(0, 0, -mTopBarSwitcher.getHeight(), 0);
			anim.setDuration(200);
			anim.setAnimationListener(new Animation.AnimationListener() {
				public void onAnimationStart(Animation animation) {
					mTopBarSwitcher.setVisibility(View.VISIBLE);
				}
				public void onAnimationRepeat(Animation animation) {}
				public void onAnimationEnd(Animation animation) {}
			});
			mTopBarSwitcher.startAnimation(anim);

			anim = new TranslateAnimation(0, 0, mPageSlider.getHeight(), 0);
			anim.setDuration(200);
			anim.setAnimationListener(new Animation.AnimationListener() {
				public void onAnimationStart(Animation animation) {
					mPageSlider.setVisibility(View.VISIBLE);
				}
				public void onAnimationRepeat(Animation animation) {}
				public void onAnimationEnd(Animation animation) {
					mPageNumberView.setVisibility(View.VISIBLE);
				}
			});
			mPageSlider.startAnimation(anim);
		}
	}

	private void hideButtons() {
		if (mButtonsVisible) {
			mButtonsVisible = false;
			hideKeyboard();

			Animation anim = new TranslateAnimation(0, 0, 0, -mTopBarSwitcher.getHeight());
			anim.setDuration(200);
			anim.setAnimationListener(new Animation.AnimationListener() {
				public void onAnimationStart(Animation animation) {}
				public void onAnimationRepeat(Animation animation) {}
				public void onAnimationEnd(Animation animation) {
					mTopBarSwitcher.setVisibility(View.INVISIBLE);
				}
			});
			mTopBarSwitcher.startAnimation(anim);

			anim = new TranslateAnimation(0, 0, 0, mPageSlider.getHeight());
			anim.setDuration(200);
			anim.setAnimationListener(new Animation.AnimationListener() {
				public void onAnimationStart(Animation animation) {
					mPageNumberView.setVisibility(View.INVISIBLE);
				}
				public void onAnimationRepeat(Animation animation) {}
				public void onAnimationEnd(Animation animation) {
					mPageSlider.setVisibility(View.INVISIBLE);
				}
			});
			mPageSlider.startAnimation(anim);
		}
	}
/*
	private void searchModeOn() {
		if (mTopBarMode != TopBarMode.Search) {
			mTopBarMode = TopBarMode.Search;
			//Focus on EditTextWidget
			mSearchText.requestFocus();
			showKeyboard();
			mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		}
	}

	private void searchModeOff() {
		if (mTopBarMode == TopBarMode.Search) {
			mTopBarMode = TopBarMode.Main;
			hideKeyboard();
			mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
			SearchTaskResult.set(null);
			// Make the ReaderView act on the change to mSearchTaskResult
			// via overridden onChildSetup method.
			mDocView.resetupChildren();
		}
	}
*/
	private void updatePageNumView(int index) {
		if (core == null)
			return;
		mPageNumberView.setText(String.format("%d / %d", index + 1, core.countPages()));
	}

	private void printDoc() {
		if (!core.fileFormat().startsWith("PDF")) {
			showInfo(getString(R.string.format_currently_not_supported));
			return;
		}

		Intent myIntent = getIntent();
		Uri docUri = myIntent != null ? myIntent.getData() : null;

		if (docUri == null) {
			showInfo(getString(R.string.print_failed));
		}

		if (docUri.getScheme() == null)
			docUri = Uri.parse("file://"+docUri.toString());

		Intent printIntent = new Intent(this, PrintDialogActivity.class);
		printIntent.setDataAndType(docUri, "aplication/pdf");
		printIntent.putExtra("title", mFileName);
		startActivityForResult(printIntent, PRINT_REQUEST);
	}

	private void showInfo(String message) {
		mInfoView.setText(message);

		int currentApiVersion = android.os.Build.VERSION.SDK_INT;
		if (currentApiVersion >= android.os.Build.VERSION_CODES.HONEYCOMB) {
			SafeAnimatorInflater safe = new SafeAnimatorInflater((Activity)this, R.animator.info, (View)mInfoView);
		} else {
			mInfoView.setVisibility(View.VISIBLE);
			mHandler.postDelayed(new Runnable() {
				public void run() {
					mInfoView.setVisibility(View.INVISIBLE);
				}
			}, 500);
		}
	}

	private void makeButtonsView() {
		mButtonsView = getLayoutInflater().inflate(R.layout.buttons,null);
		mFilenameView = (TextView)mButtonsView.findViewById(R.id.docNameText);
		mPageSlider = (SeekBar)mButtonsView.findViewById(R.id.pageSlider);
		mPageNumberView = (TextView)mButtonsView.findViewById(R.id.pageNumber);
		mInfoView = (TextView)mButtonsView.findViewById(R.id.info);
		mSearchButton = (ImageButton)mButtonsView.findViewById(R.id.searchButton);
		mReflowButton = (ImageButton)mButtonsView.findViewById(R.id.reflowButton);
		mOutlineButton = (ImageButton)mButtonsView.findViewById(R.id.outlineButton);
		mAnnotButton = (ImageButton)mButtonsView.findViewById(R.id.editAnnotButton);
		
		inkButton = (ImageButton)mButtonsView.findViewById(R.id.inkButton);
		if (!permissionMode.equalsIgnoreCase("rw")){
			inkButton.setVisibility(View.INVISIBLE);
		}
		
		magicButton = (ImageButton)mButtonsView.findViewById(R.id.magicButton);
		if (!permissionMode.equalsIgnoreCase("rw")){
			magicButton.setVisibility(View.INVISIBLE);
		}
		
		mAnnotTypeText = (TextView)mButtonsView.findViewById(R.id.annotType);
		mTopBarSwitcher = (ViewAnimator)mButtonsView.findViewById(R.id.switcher);
		mSearchBack = (ImageButton)mButtonsView.findViewById(R.id.searchBack);
		mSearchFwd = (ImageButton)mButtonsView.findViewById(R.id.searchForward);
		mSearchText = (EditText)mButtonsView.findViewById(R.id.searchText);
		mLinkButton = (ImageButton)mButtonsView.findViewById(R.id.linkButton);
		mMoreButton = (ImageButton)mButtonsView.findViewById(R.id.moreButton);
		mProofButton = (ImageButton)mButtonsView.findViewById(R.id.proofButton);
		mSepsButton = (ImageButton)mButtonsView.findViewById(R.id.sepsButton);
		mTopBarSwitcher.setVisibility(View.INVISIBLE);
		mPageNumberView.setVisibility(View.INVISIBLE);
		mInfoView.setVisibility(View.INVISIBLE);

		mPageSlider.setVisibility(View.INVISIBLE);
		if (!core.gprfSupported()) {
			mProofButton.setVisibility(View.INVISIBLE);
		}
		mSepsButton.setVisibility(View.INVISIBLE);
		mMoreButton.performClick();		//mMoreButton.callOnClick();
	}

	public void OnMoreButtonClick(View v) {
		//mTopBarMode = TopBarMode.More;
		//mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		
		mTopBarMode = TopBarMode.Annot;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());		
		
	}

	public void OnCancelMoreButtonClick(View v) {
		mTopBarMode = TopBarMode.Main;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		
		//mTopBarMode = TopBarMode.More;
		//mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());		
		
	}

	public void OnPrintButtonClick(View v) {
		printDoc();
	}

	//  start a proof activity with the given resolution.
	public void proofWithResolution (int resolution)
	{
		mProofFile = core.startProof(resolution);
		Uri uri = Uri.parse("file://"+mProofFile);
		Intent intent = new Intent(this, MuPDFActivity.class);
		intent.setAction(Intent.ACTION_VIEW);
		intent.setData(uri);
		// add the current page so it can be found when the activity is running
		intent.putExtra("startingPage", mDocView.getDisplayedViewIndex());
		startActivityForResult(intent, PROOF_REQUEST);
	}

	public void OnProofButtonClick(final View v)
	{
		//  set up the menu or resolutions.
		final PopupMenu popup = new PopupMenu(this, v);
		popup.getMenu().add(0, 1,    0, "Select a resolution:");
		popup.getMenu().add(0, 72,   0, "72");
		popup.getMenu().add(0, 96,   0, "96");
		popup.getMenu().add(0, 150,  0, "150");
		popup.getMenu().add(0, 300,  0, "300");
		popup.getMenu().add(0, 600,  0, "600");
		popup.getMenu().add(0, 1200, 0, "1200");
		popup.getMenu().add(0, 2400, 0, "2400");

		//  prevent the first item from being dismissed.
		//  is there not a better way to do this?  It requires minimum API 14
		MenuItem item = popup.getMenu().getItem(0);
		item.setShowAsAction(MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);
		item.setActionView(new View(v.getContext()));
		item.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
			@Override
			public boolean onMenuItemActionExpand(MenuItem item) {
				return false;
			}

			@Override
			public boolean onMenuItemActionCollapse(MenuItem item) {
				return false;
			}
		});

		popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
			@Override
			public boolean onMenuItemClick(MenuItem item) {
				int id = item.getItemId();
				if (id != 1) {
					//  it's a resolution.  The id is also the resolution value
					proofWithResolution(id);
					return true;
				}
				return false;
			}
		});

		popup.show();
	}

	public void OnSepsButtonClick(final View v)
	{
		if (isProofing()) {

			//  get the current page
			final int currentPage = mDocView.getDisplayedViewIndex();

			//  buid a popup menu based on the given separations
			final PopupMenu menu = new PopupMenu(this, v);

			//  This makes the popup menu display icons, which by default it does not do.
			//  I worry that this relies on the internals of PopupMenu, which could change.
			try {
				Field[] fields = menu.getClass().getDeclaredFields();
				for (Field field : fields) {
					if ("mPopup".equals(field.getName())) {
						field.setAccessible(true);
						Object menuPopupHelper = field.get(menu);
						Class<?> classPopupHelper = Class.forName(menuPopupHelper
								.getClass().getName());
						Method setForceIcons = classPopupHelper.getMethod(
								"setForceShowIcon", boolean.class);
						setForceIcons.invoke(menuPopupHelper, true);
						break;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (1==1){
				int i= menu.getGravity();
				i=i++;
			}
			//  get the maximum number of seps on any page.
			//  We use this to dimension an array further down
			int maxSeps = 0;
			int numPages = core.countPages();
			for (int page=0; page<numPages; page++) {
				int numSeps = core.getNumSepsOnPage(page);
				if (numSeps>maxSeps)
					maxSeps = numSeps;
			}

			//  if this is the first time, create the "enabled" array
			if (mSepEnabled==null) {
				mSepEnabled = new boolean[numPages][maxSeps];
				for (int page=0; page<numPages; page++) {
					for (int i = 0; i < maxSeps; i++)
						mSepEnabled[page][i] = true;
				}
			}

			//  count the seps on this page
			int numSeps = core.getNumSepsOnPage(currentPage);

			//  for each sep,
			for (int i = 0; i < numSeps; i++) {

//				//  Robin use this to skip separations
//				if (i==12)
//					break;

				//  get the name
				Separation sep = core.getSep(currentPage,i);
				String name = sep.name;

				//  make a checkable menu item with that name
				//  and the separation index as the id
				MenuItem item = menu.getMenu().add(0, i, 0, name+"    ");
				item.setCheckable(true);

				//  set an icon that's the right color
				int iconSize = 48;
				int alpha = (sep.rgba >> 24) & 0xFF;
				int red   = (sep.rgba >> 16) & 0xFF;
				int green = (sep.rgba >> 8 ) & 0xFF;
				int blue  = (sep.rgba >> 0 ) & 0xFF;
				int color = (alpha << 24) | (red << 16) | (green << 8) | (blue << 0);

				ShapeDrawable swatch = new ShapeDrawable (new RectShape());
				swatch.setIntrinsicHeight(iconSize);
				swatch.setIntrinsicWidth(iconSize);
				swatch.setBounds(new Rect(0, 0, iconSize, iconSize));
				swatch.getPaint().setColor(color);
				item.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
				item.setIcon(swatch);

				//  check it (or not)
				item.setChecked(mSepEnabled[currentPage][i]);

				//  establishing a menu item listener
				item.setOnMenuItemClickListener(new OnMenuItemClickListener() {
					@Override
					public boolean onMenuItemClick(MenuItem item) {
						//  someone tapped a menu item.  get the ID
						int sep = item.getItemId();

						//  toggle the sep
						mSepEnabled[currentPage][sep] = !mSepEnabled[currentPage][sep];
						item.setChecked(mSepEnabled[currentPage][sep]);
						core.controlSepOnPage(currentPage, sep, !mSepEnabled[currentPage][sep]);

						//  prevent the menu from being dismissed by these items
						item.setShowAsAction(MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);
						item.setActionView(new View(v.getContext()));
						item.setOnActionExpandListener(new MenuItem.OnActionExpandListener() {
							@Override
							public boolean onMenuItemActionExpand(MenuItem item) {
								return false;
							}

							@Override
							public boolean onMenuItemActionCollapse(MenuItem item) {
								return false;
							}
						});
						return false;
					}
				});

				//  tell core to enable or disable each sep as appropriate
				//  but don't refresh the page yet.
				core.controlSepOnPage(currentPage, i, !mSepEnabled[currentPage][i]);
			}

			//  add one for done
			MenuItem itemDone = menu.getMenu().add(0, 0, 0, "Done");
			itemDone.setOnMenuItemClickListener(new OnMenuItemClickListener() {
				@Override
				public boolean onMenuItemClick(MenuItem item) {
					//  refresh the view
					mDocView.refresh(false);
					return true;
				}
			});

			//  show the menu
			menu.show();
		}

	}

	public void OnCopyTextButtonClick(View v) {
		mTopBarMode = TopBarMode.Accept;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mAcceptMode = AcceptMode.CopyText;
		mDocView.setMode(MuPDFReaderView.Mode.Selecting);
		mAnnotTypeText.setText(getString(R.string.copy_text));
		showInfo(getString(R.string.select_text));
	}

	public void OnEditAnnotButtonClick(View v) {
		mTopBarMode = TopBarMode.Annot;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
	}

	public void OnCancelAnnotButtonClick(View v) {
		//mTopBarMode = TopBarMode.More;
		//mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mTopBarMode = TopBarMode.Main;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		/*
		if (core != null && core.hasChanges()) {
			//don't let rotate the screen
		}
		else{
			unlockScreenOrientation(this);	
		}*/
	}
/*
	public void OnHighlightButtonClick(View v) {
		mTopBarMode = TopBarMode.Accept;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mAcceptMode = AcceptMode.Highlight;
		mDocView.setMode(MuPDFReaderView.Mode.Selecting);
		mAnnotTypeText.setText(R.string.highlight);
		showInfo(getString(R.string.select_text));
	}

	public void OnUnderlineButtonClick(View v) {
		mTopBarMode = TopBarMode.Accept;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mAcceptMode = AcceptMode.Underline;
		mDocView.setMode(MuPDFReaderView.Mode.Selecting);
		mAnnotTypeText.setText(R.string.underline);
		showInfo(getString(R.string.select_text));
	}

	public void OnStrikeOutButtonClick(View v) {
		mTopBarMode = TopBarMode.Accept;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mAcceptMode = AcceptMode.StrikeOut;
		mDocView.setMode(MuPDFReaderView.Mode.Selecting);
		mAnnotTypeText.setText(R.string.strike_out);
		showInfo(getString(R.string.select_text));
	}
*/
	
	
	public void shareDocument(){
		List<Intent> targetedShareIntents = new ArrayList<Intent>();
        Intent shareIntent = new Intent(android.content.Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        List<ResolveInfo> resInfo = getPackageManager().queryIntentActivities(shareIntent, 0);
        if (!resInfo.isEmpty()){
            for (ResolveInfo resolveInfo : resInfo) {
                String packageName = resolveInfo.activityInfo.packageName;
                Log.d("ro.rookie.dev.testIntents", packageName);
                Intent targetedShareIntent = new Intent(android.content.Intent.ACTION_SEND);
                targetedShareIntent.setType("text/plain");
                 //application/pdf
                targetedShareIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "PDF Document");
                
                //ArrayList<Uri> uris = new ArrayList<Uri>();
                //File fileIn = new File(mOriginalPDF);
                //Uri u = Uri.fromFile(fileIn);
                //uris.add(u);
                //targetedShareIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);                                    
                Log.d("com.tssw.mupdf","mOriginalPDF: "+Uri.parse("file://"+path));
                targetedShareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse("file://"+path));//Uri.parse("file://sdcard/dcim/Camera/filename.jpg"));
                targetedShareIntent.putExtra("CustomIntentSender",this.getPackageName());
                targetedShareIntent.putExtra(Intent.EXTRA_TEXT, "Please find your Document Attached."+"\n"+"");//this.extractText()                                    
                targetedShareIntent.setPackage(packageName);
                ArrayList<String> savedPackageList = appPrefs.getPackageList("SENDpackageList");

                if (savedPackageList.contains(packageName))
                    targetedShareIntents.add(targetedShareIntent);
                /*
                if (true 
                        || packageName.contains("katana") 
                        || packageName.contains("email") 
                        ||  packageName.contains("bluetooth")
                        ||  packageName.contains("twitter")
                        ){
                    
                }
                * 
                */
            }
            if (targetedShareIntents.size()>0){
                Intent chooserIntent = Intent.createChooser(targetedShareIntents.remove(0), "Select app to share");
                chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, targetedShareIntents.toArray(new Parcelable[]{}));
                startActivityForResult(chooserIntent,0);
            }
            else {
                AlertDialog alert = mAlertBuilder.create();
                alert.setTitle("Warning");
                alert.setMessage("No programs available for the selected action!");
                alert.setButton(AlertDialog.BUTTON_POSITIVE, "Close",
                                new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                        }
                                });
                alert.show();
                return;
            }
        }
	}
	public void OnMagicButtonClick(View v){
		
		String[] a = core.getWidgetNamesInternal(0);
		RectF[] rect = core.getWidgetAreas(0);
		
		
		AlertDialog.Builder builderSingle = new AlertDialog.Builder(this);
		//builderSingle.setIcon(R.drawable.ic_launcher);
		builderSingle.setTitle("Select One Field");

		final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.select_dialog_singlechoice);
		
		
		if (a!=null)
		for (int i=0;i<a.length;i++){
			//Log.d(TAG,"Type a["+i+"]"+a[i]);
			//Log.d(TAG,"Type rect["+i+"]"+rect[i].toShortString());
			Log.d(TAG,"Type a["+i+"]"+a[i]+" -> "+rect[i].toShortString());
			//if (a[i].equalsIgnoreCase("_tsswsignature")){
			if (a[i].startsWith("_tssw")){
				arrayAdapter.add(a[i]);
			}
		}
		builderSingle.setNegativeButton(
		        "cancel",
		        new DialogInterface.OnClickListener() {
		            @Override
		            public void onClick(DialogInterface dialog, int which) {
		                dialog.dismiss();
		            }
		        });
		
		builderSingle.setAdapter(
		        arrayAdapter,
		        new DialogInterface.OnClickListener() {
		            @Override
		            public void onClick(DialogInterface dialog, int which) {
		                String strName = arrayAdapter.getItem(which);
		                
		                String[] a = core.getWidgetNamesInternal(0);
		        		RectF[] rect = core.getWidgetAreas(0);		                
		        		for (int i=0;i<a.length;i++){
		        			if (a[i].equalsIgnoreCase(strName)){
		        				Log.d(TAG,"clicking on : "+a[i]);
		        				MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
		        				//MuPDFPageView pageView = (MuPDFPageView) getDisplayedView();

		        				//pageView.passClickEventModded((rect[0].left+rect[0].right)/2,(rect[0].top+rect[0].bottom)/2);
		        				pageView.passClickEventModded(rect[i].left,rect[i].top);
		        				//pageView.passClickEvent( rect[i].left,rect[i].top);
		        				//tsswtext_pcs -> [545.57,553.73596][763.178,596.252]

		        				break;
		        			}
		        		}		                
		            }
		        });
		builderSingle.show();
		
	}
	public void OnShareButtonClick(View v) {

		if (core != null && core.hasChanges() && permissionMode.equalsIgnoreCase("rw")) {
			DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					if (which == AlertDialog.BUTTON_POSITIVE){
						core.save();
						Log.d(TAG,"core.checkFocusedSignature: "+core.checkFocusedSignature());
						shareDocument();
						//finish();
					}
					
					/*
                    if (core != null)
                    core.onDestroy();
                     core = null; 
                     Uri uri = Uri.parse(path);
                    Intent refresh = new Intent(getApplicationContext(),MuPDFActivity.class);
                    refresh.setAction(android.content.Intent.ACTION_VIEW);
                    refresh.setDataAndType(uri, "application/pdf");    
                    refresh.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(refresh);
                     
                    finish();
                    */					
						//core = openFile(path);
//						MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
	//					pageView.saveDraw();
						/*
						if (pageView != null){
							pageView.resetupChildren();
						}
							*/
						

				}
			};
			AlertDialog alert = mAlertBuilder.create();
			alert.setTitle("MuPDF");
			alert.setMessage(getString(R.string.document_has_changes_save_them_before));
			alert.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes), listener);
			alert.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no), listener);
			alert.show();
		} else {
			shareDocument();
		}
		
		
	}
	
	public void OnInkButtonClick(View v) {
		/*
		Annotation a[] = core.getAnnoations(0);
		for (int i=0;i<a.length;i++){
			Log.d(TAG,"Type a["+i+"]"+a[i].type);
		}
		 */
		
		float centerX=0;//(left+right)/2;
		float centerY=0;//(top+bottom)/2;
		float width=0;//right-left;

		String[] a = core.getWidgetNamesInternal(0);
		RectF[] rect = core.getWidgetAreas(0);
		
		if (a!=null)
		for (int i=0;i<a.length;i++){
			//Log.d(TAG,"Type a["+i+"]"+a[i]);
			//Log.d(TAG,"Type rect["+i+"]"+rect[i].toShortString());
			//Log.d(TAG,"Type a["+i+"]"+a[i]+" -> "+rect[i].toShortString());
			if (a[i].equalsIgnoreCase("_tsswsignature")){
				centerX = (rect[i].left+rect[i].right)/2;
				centerY = (rect[i].top+rect[i].bottom)/2;
				width = rect[i].right-rect[i].left;
			}
		}
		

		
		//isSignatureAvailable=true;
		//mDocView.computeFocusPoint(centerX,centerY,width);		
		
		lockScreenOrientation(this);
		mTopBarMode = TopBarMode.Accept;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mAcceptMode = AcceptMode.Ink;
		mDocView.setMode(MuPDFReaderView.Mode.Drawing);
		mAnnotTypeText.setText(R.string.ink);
		showInfo(getString(R.string.draw_annotation));
	}

	public void OnCancelAcceptButtonClick(View v) {
		MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
		if (pageView != null) {
			pageView.deselectText();
			pageView.cancelDraw();
		}
		mDocView.setMode(MuPDFReaderView.Mode.Viewing);
		switch (mAcceptMode) {
		case CopyText:
			mTopBarMode = TopBarMode.More;
			break;
		default:
			mTopBarMode = TopBarMode.Annot;
			break;
		}
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());

			unlockScreenOrientation(this);	

	}

	public void OnAcceptButtonClick(View v) {
		MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
		boolean success = false;
		switch (mAcceptMode) {
		case CopyText:
			if (pageView != null)
				success = pageView.copySelection();
			mTopBarMode = TopBarMode.More;
			showInfo(success?getString(R.string.copied_to_clipboard):getString(R.string.no_text_selected));
			break;

		case Highlight:
			if (pageView != null)
				success = pageView.markupSelection(Annotation.Type.HIGHLIGHT);
			mTopBarMode = TopBarMode.Annot;
			if (!success)
				showInfo(getString(R.string.no_text_selected));
			break;

		case Underline:
			if (pageView != null)
				success = pageView.markupSelection(Annotation.Type.UNDERLINE);
			mTopBarMode = TopBarMode.Annot;
			if (!success)
				showInfo(getString(R.string.no_text_selected));
			break;

		case StrikeOut:
			if (pageView != null)
				success = pageView.markupSelection(Annotation.Type.STRIKEOUT);
			mTopBarMode = TopBarMode.Annot;
			if (!success)
				showInfo(getString(R.string.no_text_selected));
			break;

		case Ink:
			if (pageView != null)
				success = pageView.saveDraw();
			mTopBarMode = TopBarMode.Annot;
			if (!success)
				showInfo(getString(R.string.nothing_to_save));
			break;
		}
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
		mDocView.setMode(MuPDFReaderView.Mode.Viewing);
		

			unlockScreenOrientation(this);	

	}
/*
	public void OnCancelSearchButtonClick(View v) {
		searchModeOff();
	}
*/
	public void OnDeleteButtonClick(View v) {
		final MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
		
		DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if (which == AlertDialog.BUTTON_POSITIVE){
					if (pageView != null)
						pageView.deleteSelectedAnnotation();
					mTopBarMode = TopBarMode.Annot;
					mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());

				}
			}
		};
		AlertDialog alert = mAlertBuilder.create();
		alert.setTitle("Delete");
		alert.setMessage(getString(R.string.document_is_signed_sure_to_delete));
		alert.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes), listener);
		alert.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no), listener);
		alert.show();
		
		
	}

	public void OnCancelDeleteButtonClick(View v) {
		MuPDFView pageView = (MuPDFView) mDocView.getDisplayedView();
		if (pageView != null)
			pageView.deselectAnnotation();
		mTopBarMode = TopBarMode.Annot;
		mTopBarSwitcher.setDisplayedChild(mTopBarMode.ordinal());
	}

	private void showKeyboard() {
		InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
		if (imm != null)
			imm.showSoftInput(mSearchText, 0);
	}

	private void hideKeyboard() {
		InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
		if (imm != null)
			imm.hideSoftInputFromWindow(mSearchText.getWindowToken(), 0);
	}

	private void search(int direction) {
		hideKeyboard();
		int displayPage = mDocView.getDisplayedViewIndex();
		SearchTaskResult r = SearchTaskResult.get();
		int searchPage = r != null ? r.pageNumber : -1;
		mSearchTask.go(mSearchText.getText().toString(), direction, displayPage, searchPage);
	}
/*
	@Override
	public boolean onSearchRequested() {
		if (mButtonsVisible && mTopBarMode == TopBarMode.Search) {
			hideButtons();
		} else {
			showButtons();
			searchModeOn();
		}
		return super.onSearchRequested();
	}
*/
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		if (mButtonsVisible && mTopBarMode != TopBarMode.Search) {
			hideButtons();
		} else {
			showButtons();
			//searchModeOff();
		}
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	protected void onStart() {
		if (core != null)
		{
			core.startAlerts();
			createAlertWaiter();
		}

		super.onStart();
	}

	@Override
	protected void onStop() {
		if (core != null)
		{
			destroyAlertWaiter();
			core.stopAlerts();
		}

		super.onStop();
	}

	@Override
	public void onBackPressed() {
		if (core != null && core.hasChanges() && permissionMode.equalsIgnoreCase("rw")) {
			DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					if (which == AlertDialog.BUTTON_POSITIVE)
						core.save();

					finish();
				}
			};
			AlertDialog alert = mAlertBuilder.create();
			alert.setTitle("MuPDF");
			alert.setMessage(getString(R.string.document_has_changes_save_them_before));
			alert.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.yes), listener);
			alert.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.no), listener);
			alert.show();
		} else {
			super.onBackPressed();
		}
	}

	@Override
	public void performPickFor(FilePicker picker) {
		mFilePicker = picker;
		Intent intent = new Intent(this, ChoosePDFActivity.class);
		intent.setAction(ChoosePDFActivity.PICK_KEY_FILE);
		startActivityForResult(intent, FILEPICK_REQUEST);
	}
	  static public boolean  isICSOrLater(){
	      return true;
	  }
	   static public void setHasPermanentMenuKey(Context context, boolean value) { 
	      if (isICSOrLater()) {
	          ViewConfiguration config = ViewConfiguration.get(context);
	          try {
	              Field f = ViewConfiguration.class.getDeclaredField("sHasPermanentMenuKey");
	              f.setAccessible(true);
	              if (f != null) {
	                  f.set(config, value);
	                  Log.i(TAG,"Successfully hacked permanent menu key");
	              }
	          } catch (Exception ex) {
	              Log.i(TAG,"Unable to hack permanent menu key: " + ex);
	          }
	      }
	  } 
	   
	   public static void lockScreenOrientation(Activity activity)
	   {   
	       WindowManager windowManager =  (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);   
	       Configuration configuration = activity.getResources().getConfiguration();   
	       int rotation = windowManager.getDefaultDisplay().getRotation(); 

	       // Search for the natural position of the device    
	       if(configuration.orientation == Configuration.ORIENTATION_LANDSCAPE &&  
	          (rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) ||  
	          configuration.orientation == Configuration.ORIENTATION_PORTRAIT &&   
	          (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270))   
	       {   
	           // Natural position is Landscape    
	           switch (rotation)   
	           {   
	               case Surface.ROTATION_0:    
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);    
	                   break;      
	               case Surface.ROTATION_90:   
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT); 
	               break;      
	               case Surface.ROTATION_180: 
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE); 
	                   break;          
	               case Surface.ROTATION_270: 
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
	                   break;
	           }
	       }
	       else
	       {
	           // Natural position is Portrait
	           switch (rotation) 
	           {
	               case Surface.ROTATION_0: 
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); 
	               break;   
	               case Surface.ROTATION_90: 
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); 
	               break;   
	               case Surface.ROTATION_180: 
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT); 
	                   break;          
	               case Surface.ROTATION_270: 
	                   activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE); 
	                   break;
	           }
	       }
	   }

	   public static void unlockScreenOrientation(Activity activity)
	   {
	       activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
	   }	
	   
	   @Override
	    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {

	        Map<String, Integer> perm = new HashMap<>();

	        switch (requestCode) {
	            case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS: {

	                for (int i = 0; i < permissions.length; i++) {
	                    NeededPerm np = allPermissions.get(permissions[i]);
	                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED || (grantResults[i] != PackageManager.PERMISSION_GRANTED && np.getAllowWithout())) {
	                        np.setPermissionGranted(true);
	                    }
	                    perm.put(permissions[i], grantResults[i]);
	                }

	                List<String> message = new ArrayList<>();
	                for (int i = 0; i < permissions.length; i++) {
	                    String permissionMessage = allPermissions.get(permissions[i]).getMessage();
	                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED && !allPermissions.get(permissions[i]).getAllowWithout() && !message.contains(permissionMessage)) {
	                        message.add(permissionMessage);
	                    }
	                }


	                if (message.size() != 0) {
	                    // Not All Permissions Granted
	                    new AlertDialog.Builder(MuPDFActivity.this)
	                            .setMessage("You need to allow access to " + String.join(", ", message) + " to continue")
	                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
	                                @Override
	                                public void onClick(DialogInterface dialog, int which) {
	                                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
	                                            Uri.parse("package:" + getPackageName()));
	                                    intent.addCategory(Intent.CATEGORY_DEFAULT);
	                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	                                    startActivity(intent);
	                                }
	                            })
	                            .setNegativeButton("Cancel", null)
	                            .create()
	                            .show();
	                }else{
	                	Toast.makeText(MuPDFActivity.this, "We have permissions", Toast.LENGTH_SHORT).show();
	                }
	            }
	            break;
	            default:
	                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
	        }
	    }	
	   
		private void checkAllPermissions() {

	        final List<String> permissionsList = new ArrayList<>();

	        if (allPermissions.size() > 0) {
	            for (String p : allPermissions.keySet()) {
	                if (!allPermissions.get(p).getPermissionGranted()) {
	                    permissionsList.add(p);
	                }

	            }

	            if (permissionsList.size() != 0) {
	                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
	            }else{
	                Toast.makeText(this, "OK!", Toast.LENGTH_SHORT).show();
	            }
	            return;
	        }

	    }	   
}
